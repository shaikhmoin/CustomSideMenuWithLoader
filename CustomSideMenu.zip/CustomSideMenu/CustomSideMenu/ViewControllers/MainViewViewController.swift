//
//  MainViewViewController.swift
//  CustomSideMenu
//
//  Created by Moin Shaikh on 10/09/21.
//

import UIKit
import Alamofire
import NVActivityIndicatorView

private let presentingIndicatorTypes = {
    return NVActivityIndicatorType.allCases.filter { $0 != .blank }
}()

class MainViewViewController: UIViewController,NVActivityIndicatorViewable {
    
    let parameters: [String: Any] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        createMainLoaderInView("")
        self.getAPICalling()
        
    }
    
    @IBAction func btnOpenSideMenuClick(_ sender: Any) {
        self.slideMenuController()?.openLeft()
    }
    
    func getAPICalling() {
        AF.request("https://gorest.co.in/public/v1/posts", method: .get, parameters: [:], encoding: JSONEncoding.default)
            .responseJSON { response in
                print(response)
            }
        
        AF.request("https://gorest.co.in/public/v1/posts", parameters: nil, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                guard let prettyJsonData = try? JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted) else {
                    print("Error: Cannot convert JSON object to Pretty JSON data")
                    return
                }
                guard let prettyPrintedJson = String(data: prettyJsonData, encoding: .utf8) else {
                    print("Error: Could print JSON in String")
                    return
                }
                
                print(prettyPrintedJson)
                
                let allContent = jsonObject["data"] as? [AnyObject]
                print(allContent!)
                self.stopLoaderAnimation()
                
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
    }
    
    //MARK: - Loader Methods
    func createMainLoaderInView(_ message : String) {
        DispatchQueue.main.async {
            let size = CGSize(width: 50, height: 50)
            let selectedIndicatorIndex = 1
            let indicatorType = presentingIndicatorTypes[selectedIndicatorIndex]
            
            self.startAnimating(size, message: message, type: indicatorType, fadeInAnimation: nil)
            
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.5) {
                NVActivityIndicatorPresenter.sharedInstance.setMessage("Authenticating...")
            }
            
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3) {
                self.stopAnimating(nil)
            }
        }
    }

    func stopLoaderAnimation() {
        DispatchQueue.main.async {
            self.stopAnimating()
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
