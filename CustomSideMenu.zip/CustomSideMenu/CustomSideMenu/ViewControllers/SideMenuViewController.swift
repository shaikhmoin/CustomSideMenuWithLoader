//
//  SideMenuViewController.swift
//  CustomSideMenu
//
//  Created by Moin Shaikh on 10/09/21.
//

import UIKit

struct model {
    var menuimg : String?
    var menuname : String?
}

class SideMenuViewController: UIViewController {
    
    @IBOutlet weak var tblSideMenu: UITableView!
    @IBOutlet var tblHeaderView: UIView!
    @IBOutlet var tblFooterView: UIView!
    
    var appRootNav : UINavigationController?
    var arrdata = [model(menuimg: "homefill", menuname: "Home"),model(menuimg: "jobfill", menuname: "Job"),model(menuimg: "shopfill", menuname: "Shop"),model(menuimg: "settingfill", menuname: "Setting")]
    var selectedArray : [IndexPath] = [IndexPath]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        tblSideMenu.delegate = self
        tblSideMenu.dataSource = self
        
        tblSideMenu.tableHeaderView = tblHeaderView
        tblSideMenu.tableFooterView = tblFooterView
        tblSideMenu.separatorStyle = .none

        tblSideMenu.register(UINib(nibName: "SideMenuTableViewCell", bundle: nil), forCellReuseIdentifier: "SideMenuTableViewCell")
    }
    
    //MARK:- Changeview controller helper
    func changeViewController(to viewController : UIViewController){
        //Change main view controlller of side menu controller
        appRootNav = UINavigationController(rootViewController: viewController)
        
        //Set navigation bar color and trxt color
        appRootNav?.navigationBar.barTintColor = .red
        appRootNav?.navigationBar.tintColor = .yellow
        appRootNav?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor:UIColor.systemPink]
        appRootNav?.navigationBar.isTranslucent = true
        appRootNav?.navigationBar.isHidden = true
        slideMenuController()?.changeMainViewController(appRootNav!, close: true)
    }
}

// MARK: - Table View DataSource
extension SideMenuViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuTableViewCell", for: indexPath as IndexPath) as! SideMenuTableViewCell
        
        cell.imgSideMenu.image = UIImage(named: arrdata[indexPath.row].menuimg!)
        cell.lblTitle.text = arrdata[indexPath.row].menuname
        
        if(selectedArray.contains(indexPath))
        {
            cell.vwMain.backgroundColor = .lightGray
        }
        else
        {
            cell.vwMain.backgroundColor = .white
        }
        
        return cell
    }
}

// MARK: - Table View Delegate
extension SideMenuViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        selectedArray.removeAll()
        if(!selectedArray.contains(indexPath))
        {
            selectedArray.append(indexPath)
        }
       
        print(selectedArray)
        
        tblSideMenu.reloadData()

        if indexPath.row == 0 {
            let productVC = storyboard.instantiateViewController(withIdentifier: "idHomeViewController") as! HomeViewController
            self.changeViewController(to: productVC)

        } else if indexPath.row == 1  {
            let productVC = storyboard.instantiateViewController(withIdentifier: "idJobViewController") as! JobViewController
            self.changeViewController(to: productVC)
        }

        else if indexPath.row == 2  {
            let productVC = storyboard.instantiateViewController(withIdentifier: "idHomeViewController") as! HomeViewController
            self.changeViewController(to: productVC)
        }

        else if indexPath.row == 3  {
            let productVC = storyboard.instantiateViewController(withIdentifier: "idJobViewController") as! JobViewController
            self.changeViewController(to: productVC)
        }
    }
}
